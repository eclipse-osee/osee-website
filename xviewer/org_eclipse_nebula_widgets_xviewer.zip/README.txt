XViewer - Plugin code and examples

Instructions:
- Extract these two plugins into your workspace
- File -> Import -> General -> Existing Projects into Workspace
- org.eclipse.nebula.widgets.xviewer.test - Test implementation of XViewer
- Find XViewerText.java file - Right-click -> Run As -> Java Application

More information at http://www.eclipse.org/osee/xviewer

